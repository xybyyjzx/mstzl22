package com.online.taxi.order.controller;


import com.online.taxi.order.service.GrabService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.*;

/** 抢单服务
 * @author 马士兵教育：晁鹏飞
 */
@RestController
@RequestMapping("/grab-driver")
public class GrabOrderController {

    // 无锁
    @Autowired
    @Qualifier("grabNoLockService")
    // jvm锁
//    @Qualifier("grabJvmLockService")
    // mysql锁
//    @Qualifier("grabMysqlLockService")
    // 手写redis
//    @Qualifier("grabRedisLockService")
    //单个Redisson=redis son
//    @Qualifier("grabRedisRedissonService")
    // 红锁
//    @Qualifier("grabRedisRedissonRedLockLockService")
    // cloud 锁
//    @Qualifier("cloudService")
    // zk 锁
//    @Qualifier("zookeeperService")
    private GrabService grabService;

    @GetMapping("/do/{orderId}")
    public String grabMysql(@PathVariable("orderId") int orderId, int driverId){
        System.out.println("order:"+orderId+",driverId:"+driverId);
        grabService.grabOrder(orderId,driverId);
        return "";
    }

    //单个redisson
    @Autowired
    @Qualifier("grabRedisRedissonService")
    private GrabService redisGrabService;


    @GetMapping("/do-redis/{orderId}")
    public String grabRedis(@PathVariable("orderId") int orderId, int driverId){
        System.out.println("order:"+orderId+",driverId:"+driverId);
        redisGrabService.grabOrder(orderId,driverId);
        return "";
    }
}