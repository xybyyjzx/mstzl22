package com.online.taxi.order.service;

public interface SeckillOrderService {
	
	public boolean grab(int goodsId, int userId);
	
}
